# TFNeuralNetworks

A custom built wrapper library for building highly encapsulated TensorFlow neural networks.
