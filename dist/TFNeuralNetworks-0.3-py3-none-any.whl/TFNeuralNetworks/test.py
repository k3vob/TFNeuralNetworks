from RNN import RNN

model = RNN(2, 2, [100], 60)
